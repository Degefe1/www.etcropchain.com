# ET Crop Chain website

Static website (HTML, CSS, JavaScript). No build step and no server needed.

## Files
```
index.html        main page
404.html          "page not found" page
css/style.css     styling
js/main.js        interactions, animations, analytics, music
images/           product photos and logo
.nojekyll         tells GitHub Pages to serve the files as they are
robots.txt        search-engine rules
```

## Deploy on GitHub Pages (easiest, no software needed)
1. Sign in at github.com and click **New repository**. Name it, for example, `et-crop-chain`. Choose **Public**, then **Create repository**.
2. Click **uploading an existing file**. Unzip this project and drag **everything inside the folder** (not the folder itself) into the page. Make sure `index.html` is at the top level. Click **Commit changes**.
3. Open **Settings → Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch**, choose branch **main** and folder **/ (root)**, then **Save**.
4. Wait about a minute. Your site will be live at `https://YOUR-USERNAME.github.io/et-crop-chain/`.

### Using Git on the command line instead
```bash
cd et-crop-chain
git init
git add .
git commit -m "ET Crop Chain website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/et-crop-chain.git
git push -u origin main
```
Then do step 3 above.

## Use your own domain (optional)
In **Settings → Pages → Custom domain**, enter your domain (for example `www.etcropchain.com`) and follow GitHub's DNS instructions. GitHub will add a `CNAME` file for you.

## Things to set up after publishing
- **Visitor analytics:** create a Google Analytics 4 property, copy the Measurement ID (looks like `G-XXXXXXXXXX`) and paste it into `GA_ID` in `js/main.js`. If you have visitors from Europe, add a cookie notice.
- **Contact details:** phone, email and Instagram are in `index.html` (search for `251973223996`, `etcropchain@gmail.com` and `crop_chain`).
- **Change a photo:** replace the file in `images/` with one of the same name.
- **Picture change speed:** `DECK_MS = 2000` in `js/main.js` (top card stack).

## Updating the site
Edit a file on GitHub (pencil icon) or push new commits. GitHub Pages republishes automatically within a minute or two.
