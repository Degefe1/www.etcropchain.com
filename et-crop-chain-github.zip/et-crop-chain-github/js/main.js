(function(){
  var reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
  /* hero deck */
  var deck=document.getElementById("deck"),cards=[].slice.call(deck.children),n=cards.length,act=0,dots=document.getElementById("dots");
  cards.forEach(function(_,i){var d=document.createElement("i");dots.appendChild(d)});
  var DECK_MS=2000;                                              /* picture changes every 2 seconds */
  function bar(){var pr=document.getElementById("prog");if(!pr||reduce)return;pr.style.animation="none";void pr.offsetWidth;pr.style.animation="fill "+DECK_MS+"ms linear forwards"}
  function layout(dx){
    cards.forEach(function(c,i){
      var rel=(i-act+n)%n,x=0,z=0,r=0,s=1,op=1;
      if(rel===0){x=dx||0;r=x*.04}
      else if(rel===1){x=40;z=-90;r=-10;s=.95}
      else if(rel===n-1){x=-40;z=-150;r=10;s=.9}
      else{z=-240;s=.85;op=0}
      c.style.zIndex=n-rel;c.style.opacity=op;c.classList.toggle("front",rel===0);
      c.style.transform="translateX("+x+"px) translateZ("+z+"px) rotateY("+r+"deg) scale("+s+")";
    });
    [].forEach.call(dots.children,function(d,i){d.className=i===act?"on":""});
  }
  function go(k){act=(act+k+n)%n;layout(0);bar();if(window.etChime)window.etChime(act)}
  var sx=0,drag=false,dxx=0,front;
  deck.addEventListener("pointerdown",function(e){drag=true;sx=e.clientX;dxx=0;front=cards[act];front.classList.add("drag");try{deck.setPointerCapture(e.pointerId)}catch(_){}});
  deck.addEventListener("pointermove",function(e){if(!drag)return;dxx=e.clientX-sx;layout(dxx)});
  function end(){if(!drag)return;drag=false;front.classList.remove("drag");if(dxx<-50)go(1);else if(dxx>50)go(-1);else layout(0)}
  deck.addEventListener("pointerup",end);deck.addEventListener("pointercancel",end);
  deck.addEventListener("keydown",function(e){if(e.key==="ArrowRight")go(1);if(e.key==="ArrowLeft")go(-1)});
  document.getElementById("next").onclick=function(){go(1)};
  document.getElementById("prev").onclick=function(){go(-1)};
  layout(0);
  bar();
  if(!reduce){setInterval(function(){if(!drag&&!deck.matches(":hover")&&!deck.contains(document.activeElement)&&!document.hidden)go(1)},DECK_MS)}
  /* product carousel */
  var car=document.getElementById("car"),moved=false,down=false,px=0,sl=0;
  function step(d){var c=car.querySelector(".pc");car.scrollBy({left:d*(c.offsetWidth+20),behavior:reduce?"auto":"smooth"})}
  document.getElementById("cl").onclick=function(){step(-1)};
  document.getElementById("cr").onclick=function(){step(1)};
  car.addEventListener("pointerdown",function(e){if(e.pointerType!=="mouse")return;down=true;moved=false;px=e.clientX;sl=car.scrollLeft});
  window.addEventListener("pointermove",function(e){if(!down)return;var d=e.clientX-px;if(Math.abs(d)>5){moved=true;car.classList.add("dragging")}if(moved)car.scrollLeft=sl-d});
  window.addEventListener("pointerup",function(){if(!down)return;down=false;car.classList.remove("dragging")});
  car.addEventListener("click",function(e){if(moved){e.preventDefault();e.stopPropagation();moved=false}},true);
  car.addEventListener("keydown",function(e){if(e.key==="ArrowRight")step(1);if(e.key==="ArrowLeft")step(-1)});
  /* 3D hover tilt (mouse only) and spec-sheet email */
  document.querySelectorAll(".pc").forEach(function(c){
    if(!reduce){
      c.addEventListener("pointermove",function(e){if(e.pointerType!=="mouse"||down)return;var r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
        c.style.transform="perspective(800px) rotateX("+(-y*9)+"deg) rotateY("+(x*9)+"deg) translateZ(8px)"});
      c.addEventListener("pointerleave",function(){c.style.transform=""});
    }
    c.addEventListener("click",function(){document.getElementById("mail").href="mailto:etcropchain@gmail.com?subject="+encodeURIComponent("Spec sheet request: "+c.dataset.p);var sel=document.getElementById("iq-crop");if(sel)sel.value=c.dataset.p});
  });
  /* scroll reveal */
  var els=document.querySelectorAll(".rv");
  if("IntersectionObserver" in window&&!reduce){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}})},{threshold:.12});
    els.forEach(function(el){io.observe(el)});
  }else els.forEach(function(el){el.classList.add("in")});
})();

/* ---------- Visitor analytics (Google Analytics 4) ----------
   1. Create a GA4 property at analytics.google.com
   2. Paste its Measurement ID below (looks like G-XXXXXXXXXX)
   Works once the site is on your own domain. */
(function(){
  var GA_ID="";
  window.dataLayer=window.dataLayer||[];
  function gtag(){dataLayer.push(arguments)}
  if(GA_ID){var s=document.createElement("script");s.async=true;s.src="https://www.googletagmanager.com/gtag/js?id="+GA_ID;document.head.appendChild(s);gtag("js",new Date());gtag("config",GA_ID,{anonymize_ip:true})}
  function track(n,p){try{gtag("event",n,p||{})}catch(e){}}
  document.addEventListener("click",function(e){
    var a=e.target.closest("a");if(!a)return;var h=a.getAttribute("href")||"";
    if(a.classList.contains("pc"))track("product_interest",{crop:a.dataset.p});
    else if(h.indexOf("wa.me")>-1)track("whatsapp_click");
    else if(h.indexOf("mailto:")===0)track("email_click");
    else if(h.indexOf("tel:")===0)track("call_click");
    else if(h.indexOf("instagram.com")>-1)track("instagram_click");
  });
  var deck=document.getElementById("deck");if(deck)deck.addEventListener("pointerdown",function(){track("featured_deck_swipe")},{once:true});
  var done={};addEventListener("scroll",function(){
    var d=document.documentElement,p=Math.round(100*(scrollY+innerHeight)/d.scrollHeight);
    [25,50,75,100].forEach(function(m){if(p>=m&&!done[m]){done[m]=1;track("scroll_depth",{percent:m})}});
  },{passive:true});
  var f=document.getElementById("inq");
  if(f)f.addEventListener("submit",function(e){
    e.preventDefault();
    var crop=document.getElementById("iq-crop").value,q=document.getElementById("iq-qty").value,d=document.getElementById("iq-dest").value;
    var msg="Hello ET Crop Chain, I am interested in "+crop+"."+(q?" Quantity: "+q+" metric tons.":"")+(d?" Destination: "+d+".":"");
    track("inquiry_whatsapp",{crop:crop});
    window.open("https://wa.me/251973223996?text="+encodeURIComponent(msg),"_blank");
  });
})();

/* ---------- Ethiopian classical-style music (synthesised; starts only when the visitor taps) ----------
   Tizita-minor pentatonic scale, krar-like plucks, a masenqo-like bowed lead and a soft drone. */
(function(){
  var btn=document.getElementById("snd"),rng=document.getElementById("sndv");if(!btn)return;
  var lbl=document.getElementById("sndl"),ctx,master,bus,on=false,tm,root=146.83,scale=[0,2,3,7,8],beat=.95;
  var P=[[0,1,2,1,0],[2,3,2,1,0,-1],[3,4,3,2,1,0],[0,-1,0,1,2,1],[2,1,2,3,2,0]];
  function lvl(){return rng.value/100*.45}
  function freq(d,o){var k=Math.floor(d/5),i=((d%5)+5)%5;return root*Math.pow(2,(scale[i]+12*(k+o))/12)}
  function build(){
    ctx=new (window.AudioContext||window.webkitAudioContext)();
    master=ctx.createGain();master.gain.value=0;
    var comp=ctx.createDynamicsCompressor();master.connect(comp);comp.connect(ctx.destination);
    bus=ctx.createBiquadFilter();bus.type="lowpass";bus.frequency.value=2400;bus.connect(master);
    var dl=ctx.createDelay(1),fb=ctx.createGain(),wet=ctx.createGain();
    dl.delayTime.value=.42;fb.gain.value=.42;wet.gain.value=.4;
    bus.connect(dl);dl.connect(fb);fb.connect(dl);dl.connect(wet);wet.connect(master);
    [[root/2,"sine",.22],[root/2*1.003,"triangle",.09],[root*.75,"sine",.12]].forEach(function(p){
      var o=ctx.createOscillator(),g=ctx.createGain();o.type=p[1];o.frequency.value=p[0];g.gain.value=p[2];o.connect(g);g.connect(bus);o.start()});
  }
  function pluck(f,t,v){
    [["triangle",1,v],["sine",2,v*.3],["sine",3,v*.1]].forEach(function(x){
      var o=ctx.createOscillator(),g=ctx.createGain();o.type=x[0];o.frequency.value=f*x[1];o.detune.value=(Math.random()-.5)*6;
      g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(x[2],t+.012);g.gain.exponentialRampToValueAtTime(.0008,t+2.6);
      o.connect(g);g.connect(bus);o.start(t);o.stop(t+2.7);
    });
  }
  function lead(f,t,dur,v){
    var o=ctx.createOscillator(),g=ctx.createGain(),lf=ctx.createBiquadFilter(),vib=ctx.createOscillator(),vg=ctx.createGain();
    o.type="sawtooth";o.frequency.setValueAtTime(f*.985,t);o.frequency.exponentialRampToValueAtTime(f,t+.25);
    lf.type="lowpass";lf.frequency.value=1100;lf.Q.value=2;
    vib.frequency.value=5.2;vg.gain.value=f*.008;vib.connect(vg);vg.connect(o.frequency);
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.35);g.gain.setValueAtTime(v,t+dur-.6);g.gain.linearRampToValueAtTime(0,t+dur);
    o.connect(lf);lf.connect(g);g.connect(bus);o.start(t);vib.start(t);o.stop(t+dur+.05);vib.stop(t+dur+.05);
  }
  function phrase(){
    if(!on)return;
    var t0=ctx.currentTime+.08,p=P[Math.floor(Math.random()*P.length)],t=t0,last=t0;
    pluck(freq(0,0),t0,.32);
    p.forEach(function(d,i){
      if(Math.random()<.35)pluck(freq(d+1,1),t-.14,.15);
      pluck(freq(d,1),t,.32);last=t;
      t+=beat*(i===p.length-1?2:(Math.random()<.3?1.5:1));
    });
    lead(freq(p[p.length-1],1),last,3.4,.07);
    tm=setTimeout(phrase,(t-t0+1.4)*1000);
  }
  /* one soft classical note for every picture change; the notes form a Tizita melody across the cards */
  var seq=[0,2,3,2,1,3,4,2,0];
  function chime(i){
    if(!on||!ctx)return;
    var t=ctx.currentTime+.03,k=i%seq.length,d=seq[k];
    if(k===0)pluck(freq(0,0),t,.32);
    pluck(freq(d,1),t,.42);
    if(k%3===2)lead(freq(d,1),t,2.6,.07);
  }
  window.etChime=chime;
  function setOn(v){
    on=v;btn.setAttribute("aria-pressed",v);lbl.textContent=v?"Music on":"Music off";
    btn.setAttribute("aria-label",v?"Turn music off":"Play Ethiopian classical music");
    if(v){if(!ctx)build();ctx.resume();master.gain.setTargetAtTime(lvl(),ctx.currentTime,1);clearTimeout(tm);chime(0)}
    else if(ctx){clearTimeout(tm);master.gain.setTargetAtTime(0,ctx.currentTime,.4);setTimeout(function(){if(!on)ctx.suspend()},1500)}
  }
  btn.addEventListener("click",function(){setOn(!on)});
  rng.addEventListener("input",function(){if(ctx&&on)master.gain.setTargetAtTime(lvl(),ctx.currentTime,.1)});
  document.addEventListener("visibilitychange",function(){if(!ctx||!on)return;document.hidden?ctx.suspend():ctx.resume()});
})();

/* ---------- Product row auto-advance (every 2 seconds; pauses on hover, touch or keyboard use) ---------- */
(function(){
  var car=document.getElementById("car");if(!car||matchMedia("(prefers-reduced-motion: reduce)").matches)return;
  var hold=0,inView=false;
  ["pointerdown","touchstart","wheel","keydown","focusin"].forEach(function(ev){car.addEventListener(ev,function(){hold=Date.now()+6000},{passive:true})});
  if("IntersectionObserver" in window)new IntersectionObserver(function(es){inView=es[0].isIntersecting}).observe(car);else inView=true;
  setInterval(function(){
    if(!inView||document.hidden||Date.now()<hold||car.matches(":hover"))return;
    var c=car.querySelector(".pc");if(!c)return;
    if(car.scrollLeft>=car.scrollWidth-car.clientWidth-6)car.scrollTo({left:0,behavior:"smooth"});
    else car.scrollBy({left:c.offsetWidth+20,behavior:"smooth"});
  },2000);
})();
